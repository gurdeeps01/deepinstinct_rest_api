import requests
import urllib3
import os
import base64
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from multiprocessing import Process

def request_enc(data, server, port):
    request = 'https://10.10.70.17:5000/scan/base64'.format(ip=server, port=port)
    result = requests.post(request, verify=False, data=data, timeout=200)
    print(result.json())
def run_request_file(filename, server='10.10.70.17', port='443'):
    try:
        with open(filename, 'rb') as f:
            data = f.read()
        data_enc = base64.b64encode(data)
        request_enc(data_enc, server, port)
    except Exception as e:
        print('failed request [{}]: {}'.format(filename, str(e)))

if __name__ == '__main__':

    workers = []
    for filename in os.listdir(r'./intelligencefiles/'):
        p = Process(target=run_request_file, args=(f'./intelligencefiles//{filename}',))
        p.start()
        workers.append(p)

    for worker in workers:
        worker.join()

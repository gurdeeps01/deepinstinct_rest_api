import requests
import urllib3
import os
import base64
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from multiprocessing import Process

def request_enc(data, server, port):
    request = 'https://10.10.70.22:5000/scan/base64'.format(ip=server, port=port)
    result = requests.post(request, verify=False, data=data, timeout=200)
    print(result.json())
    if (result.json().get("verdict") =="Malicious"):
        #print("deleteme")
        return 1
    return 0
def run_request_file(filename, server='34.87.15.83', port='443'):
    try:
        with open(filename, 'rb') as f:
            data = f.read()
        data_enc = base64.b64encode(data)
        if (request_enc(data_enc, server, port) ==1):
            os.remove(filename)
    except Exception as e:
        print('failed request [{}]: {}'.format(filename, str(e)))

if __name__ == '__main__':

    files = []
    workers = []
    for filename in os.listdir(r'./intelligencefiles/'):
        files.append(filename)
        p = Process(target=run_request_file, args=(f'./intelligencefiles//{filename}',))
        p.start()
        workers.append(p)

    for worker in workers:
        worker.join()
